package 확인문제;

public class Truck extends Car {
	int 트렁크크기;
	
	public void 짐() {
		System.out.println(트렁크크기+"만큼 짐을 넣을 수 있는 트럭입니다.");
	}
	
}
